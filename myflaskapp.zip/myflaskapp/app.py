from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np

app = Flask(__name__)

# تحميل الموديل والسكالر
with open('random_forest_model1.pkl', 'rb') as f:
    model = pickle.load(f)

with open('scaler1.pkl', 'rb') as f:
    scaler = pickle.load(f)


# 🧮 المسار الأول: واجهة HTML (الفورم)
@app.route('/', methods=['GET', 'POST'])
def predict():
    prediction = None
    if request.method == 'POST':
        try:
            # قراءة القيم من الفورم
            ram = float(request.form['ram'])
            fc = float(request.form['fc'])
            px_width = float(request.form['px_width'])
            px_height = float(request.form['px_height'])
            battery_power = float(request.form['battery_power'])

            # ترتيب وتحويل البيانات
            input_data = np.array([[ram, fc, px_width, px_height, battery_power]])
            input_data_scaled = scaler.transform(input_data)

            # التنبؤ
            prediction = model.predict(input_data_scaled)[0]
        except:
            prediction = "Error: تأكدي من إدخال قيم صحيحة!"

    return render_template('predict_form.html', prediction=prediction)


# 🔥 المسار الثاني: API (JSON)
@app.route('/predict_api', methods=['POST'])
def predict_api():
    try:
        # استلام البيانات بصيغة JSON
        data = request.get_json(force=True)

        # استخراج القيم من JSON
        ram = float(data['ram'])
        fc = float(data['fc'])
        px_width = float(data['px_width'])
        px_height = float(data['px_height'])
        battery_power = float(data['battery_power'])

        # ترتيب وتحويل البيانات
        input_data = np.array([[ram, fc, px_width, px_height, battery_power]])
        input_data_scaled = scaler.transform(input_data)

        # التنبؤ
        prediction = model.predict(input_data_scaled)[0]

        # إرجاع النتيجة بصيغة JSON
        return jsonify({'Predicted Price Range': int(prediction)})

    except Exception as e:
        return jsonify({'Error': str(e)})


if __name__ == "__main__":
    app.run(debug=True)
