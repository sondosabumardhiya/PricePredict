from django.db import models

class MakePrediction(models.Model):
    battery_power = models.IntegerField()
    ram = models.IntegerField()
    internal_memory = models.IntegerField()
    px_height = models.IntegerField()
    px_width = models.IntegerField()
    predicted_price = models.IntegerField()

    def __str__(self):
        return f"{self.predicted_price}"
