from django.contrib import admin
from .models import MakePrediction
 
# تسجيل الموديل في لوحة الإدارة
admin.site.register(MakePrediction)
 