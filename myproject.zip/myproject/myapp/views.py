import pandas as pd
import joblib
from django.shortcuts import render
from django.http import HttpResponse

# تحميل النموذج وscaler مرة واحدة عند بدء السيرفر
model = joblib.load('myapp/random_forest_model1.pkl')
scaler = joblib.load('myapp/scaler1.pkl')

# قائمة لحفظ إدخالات المستخدم
user_inputs_list = []

def home(request):
    return render(request, 'home.html')

def predict_price(request):
    global user_inputs_list
    result = None

    if request.method == 'POST':
        # جمع القيم من الفورم
        ram = int(request.POST.get('ram'))
        fc  = int(request.POST.get('fc'))  # الكاميرا الأمامية
        px_width  = int(request.POST.get('px_width'))
        px_height = int(request.POST.get('px_height'))
        battery_power = int(request.POST.get('battery_power'))

        # تجهيز البيانات للنموذج بنفس ترتيب الأعمدة الذي تم التدريب عليه
        X = pd.DataFrame([[ram, fc, px_width, px_height, battery_power]],
                         columns=['ram', 'fc', 'px_width', 'px_height', 'battery_power'])
        X_scaled = scaler.transform(X)  # تحويل القيم باستخدام scaler
        predicted_price = model.predict(X_scaled)[0]  # التنبؤ

        result = predicted_price

        # حفظ الإدخال لعرضه لاحقًا أو تحميله
        entry = {
            'ram': ram,
            'fc': fc,
            'px_width': px_width,
            'px_height': px_height,
            'battery_power': battery_power,
            'predicted_price': predicted_price
        }
        user_inputs_list.append(entry)

    # تنزيل Excel
    if request.GET.get('export') == 'excel' and user_inputs_list:
        df = pd.DataFrame(user_inputs_list)
        response = HttpResponse(content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename="predictions.xlsx"'
        df.to_excel(response, index=False)
        return response

    return render(request, 'predict.html', {'result': result, 'user_inputs_list': user_inputs_list})
