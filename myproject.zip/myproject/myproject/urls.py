from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),                   # الصفحة الرئيسية
    path('predict/', views.predict_price, name='predict_price'),  # صفحة التنبؤ
]
